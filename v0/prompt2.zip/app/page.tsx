"use client";

import { Layout } from "@/components/Layout";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import i18n from "i18next";
import { initReactI18next, I18nextProvider } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, ShoppingBag, TrendingUp, Clock } from "lucide-react";

// Initialize i18next
i18n.use(initReactI18next).init({
  resources: {
    en: {
      translation: {
        "nav.explore": "Explore",
        "nav.myGroups": "My Groups",
        "nav.create": "Create",
        "nav.saved": "Saved",
        "nav.profile": "Profile",
        "nav.notifications": "Notifications",
        "nav.pastListings": "Past Listings",
        "nav.language": "Language",
        "nav.logout": "Log out",
        "nav.adminCrm": "Admin CRM",
        "footer.rights": "All rights reserved.",
        "footer.terms": "Terms",
        "footer.privacy": "Privacy",
        "footer.contact": "Contact",
      },
    },
  },
  lng: "en",
  fallbackLng: "en",
  interpolation: {
    escapeValue: false,
  },
});

const queryClient = new QueryClient();

function DemoContent() {
  const stats = [
    {
      title: "Active Groups",
      value: "24",
      icon: Users,
      trend: "+12%",
    },
    {
      title: "Total Savings",
      value: "$1,847",
      icon: TrendingUp,
      trend: "+8%",
    },
    {
      title: "Items Purchased",
      value: "156",
      icon: ShoppingBag,
      trend: "+23%",
    },
    {
      title: "Pending Orders",
      value: "3",
      icon: Clock,
      trend: "0",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-balance">
          Welcome back, Alex
        </h1>
        <p className="text-muted-foreground mt-1">
          Here&apos;s what&apos;s happening with your group buys today.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.title} className="border-border/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground mt-1">
                <span className="text-accent font-medium">{stat.trend}</span>{" "}
                from last month
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                title: "Organic Coffee Bundle",
                status: "2 more needed",
                time: "2h ago",
              },
              {
                title: "Wireless Earbuds Group",
                status: "Ready to order",
                time: "5h ago",
              },
              {
                title: "Fitness Equipment Set",
                status: "You joined",
                time: "1d ago",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="flex items-center justify-between py-2 border-b border-border/40 last:border-0"
              >
                <div>
                  <p className="font-medium text-sm">{item.title}</p>
                  <p className="text-xs text-muted-foreground">{item.status}</p>
                </div>
                <span className="text-xs text-muted-foreground">
                  {item.time}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Home() {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nextProvider i18n={i18n}>
        <Layout>
          <DemoContent />
        </Layout>
      </I18nextProvider>
    </QueryClientProvider>
  );
}
