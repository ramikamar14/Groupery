"use client";

import { useState, useCallback } from "react";

interface User {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  isVerified?: boolean;
  isAdmin?: boolean;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export function useAuth() {
  const [authState] = useState<AuthState>({
    user: {
      id: "1",
      email: "demo@grouperry.com",
      firstName: "Alex",
      lastName: "Demo",
      isVerified: true,
      isAdmin: false,
    },
    isAuthenticated: true,
    isLoading: false,
  });

  const logout = useCallback(() => {
    // Logout logic would go here
    console.log("Logout called");
  }, []);

  const login = useCallback(async (_email: string, _password: string) => {
    // Login logic would go here
    console.log("Login called");
  }, []);

  return {
    ...authState,
    logout,
    login,
  };
}
