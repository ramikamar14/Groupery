"use client";

interface LogoIconProps {
  size?: number;
  className?: string;
}

export function LogoIcon({ size = 32, className }: LogoIconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <rect width="32" height="32" rx="8" className="fill-primary" />
      <path
        d="M10 12C10 10.8954 10.8954 10 12 10H20C21.1046 10 22 10.8954 22 12V14C22 15.1046 21.1046 16 20 16H12C10.8954 16 10 15.1046 10 14V12Z"
        className="fill-primary-foreground"
      />
      <path
        d="M10 18C10 16.8954 10.8954 16 12 16H16C17.1046 16 18 16.8954 18 18V20C18 21.1046 17.1046 22 16 22H12C10.8954 22 10 21.1046 10 20V18Z"
        className="fill-accent"
      />
      <circle cx="22" cy="20" r="4" className="fill-accent" />
    </svg>
  );
}
