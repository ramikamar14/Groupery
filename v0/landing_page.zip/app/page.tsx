import {
  Header,
  Hero,
  Stats,
  HowItWorks,
  Categories,
  Trust,
  CTA,
  Footer,
} from "@/components/landing";

// Mock platform stats for demo
const platformStats = { activeListings: 847, totalMembers: 12500 };

export default function Landing() {
  return (
    <div className="min-h-screen bg-background flex flex-col" data-testid="landing-page">
      <Header />
      <Hero totalMembers={platformStats.totalMembers} />
      <Stats 
        activeListings={platformStats.activeListings} 
        totalMembers={platformStats.totalMembers} 
      />
      <HowItWorks />
      <Categories />
      <Trust />
      <CTA />
      <Footer />
    </div>
  );
}
