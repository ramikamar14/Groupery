import {
  Header,
  Hero,
  Stats,
  HowItWorks,
  Categories,
  Trust,
  CTA,
  Footer,
} from "@/components/landing-v2";

export const metadata = {
  title: "Grouperry V2 - Warm & Playful Design",
  description: "Join group deals and save up to 30% on your purchases. AI-powered group buying platform.",
};

export default function LandingPageV2() {
  return (
    <div className="theme-v2 min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <Hero />
        <Stats />
        <HowItWorks />
        <Categories />
        <Trust />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
