"use client";

import { Badge } from "@/components/ui/badge";
import { Users, UserPlus, CheckCircle, Handshake, Zap, type LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { fadeUp, staggerContainer } from "@/lib/animations";
import { t } from "@/lib/translations";

interface Step {
  icon: LucideIcon;
  title: string;
  desc: string;
  num: string;
  color: string;
}

export function HowItWorks() {
  const steps: Step[] = [
    { icon: Users, title: t("landing.step1Title"), desc: t("landing.step1Desc"), num: "01", color: "bg-blue-500 text-white" },
    { icon: UserPlus, title: t("landing.step2Title"), desc: t("landing.step2Desc"), num: "02", color: "bg-accent text-accent-foreground" },
    { icon: CheckCircle, title: t("landing.step3Title"), desc: t("landing.step3Desc"), num: "03", color: "bg-emerald-500 text-white" },
    { icon: Handshake, title: t("landing.step4Title"), desc: t("landing.step4Desc"), num: "04", color: "bg-amber-500 text-white" },
  ];

  return (
    <section id="how-it-works" className="py-28 sm:py-36">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div 
          className="text-center mb-20" 
          initial="hidden" 
          whileInView="visible" 
          viewport={{ once: true, margin: "-80px" }} 
          variants={fadeUp} 
          transition={{ duration: 0.5 }}
        >
          <Badge variant="secondary" className="gap-2 px-4 py-1.5 text-sm font-medium mb-6 inline-flex border border-accent/30 bg-accent/10 text-accent">
            <Zap className="w-4 h-4" />
            Simple by design
          </Badge>
          <h2 className="text-4xl sm:text-5xl font-bold text-balance" data-testid="text-how-it-works">{t("landing.howItWorks")}</h2>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" 
          initial="hidden" 
          whileInView="visible" 
          viewport={{ once: true, margin: "-80px" }} 
          variants={staggerContainer}
        >
          {steps.map((step, i) => (
            <motion.div key={i} variants={fadeUp} transition={{ duration: 0.4 }}>
              <div 
                className="relative bg-card border-l-4 border-l-primary border border-border/60 rounded-xl p-7 h-full hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 group" 
                data-testid={`card-step-${i}`}
              >
                {/* Decorative step number */}
                <div className="absolute -top-4 -right-2 w-16 h-16 flex items-center justify-center">
                  <span className="text-6xl font-bold text-border/40 group-hover:text-primary/20 transition-colors">{step.num}</span>
                </div>
                
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-5 ${step.color}`}>
                  <step.icon className="w-7 h-7" />
                </div>
                <h3 className="text-lg font-semibold mb-3">{step.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{step.desc}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
