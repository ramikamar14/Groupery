"use client";

import { Smartphone, ShoppingCart, Tv, Shirt, Sofa, Plane, type LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { useRef } from "react";
import { fadeUp, staggerContainer } from "@/lib/animations";
import { t } from "@/lib/translations";

interface Category {
  icon: LucideIcon;
  title: string;
  desc: string;
  color: string;
}

export function Categories() {
  const categoriesRef = useRef<HTMLDivElement>(null);

  const categories: Category[] = [
    { icon: Smartphone, title: t("landing.catElectronics"), desc: t("landing.catElectronicsDesc"), color: "bg-blue-500" },
    { icon: ShoppingCart, title: t("landing.catFood"), desc: t("landing.catFoodDesc"), color: "bg-emerald-500" },
    { icon: Tv, title: t("landing.catSubscriptions"), desc: t("landing.catSubscriptionsDesc"), color: "bg-accent" },
    { icon: Shirt, title: t("landing.catFashion"), desc: t("landing.catFashionDesc"), color: "bg-pink-500" },
    { icon: Sofa, title: t("landing.catHome"), desc: t("landing.catHomeDesc"), color: "bg-amber-500" },
    { icon: Plane, title: t("landing.catTravel"), desc: t("landing.catTravelDesc"), color: "bg-cyan-500" },
  ];

  return (
    <section className="py-28 sm:py-36 bg-secondary/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div 
          className="text-center mb-16" 
          initial="hidden" 
          whileInView="visible" 
          viewport={{ once: true, margin: "-80px" }} 
          variants={fadeUp} 
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl sm:text-5xl font-bold text-balance" data-testid="text-categories-title">{t("landing.categoriesTitle")}</h2>
        </motion.div>
        
        {/* Mobile: Horizontal scroll */}
        <div 
          ref={categoriesRef}
          className="flex lg:hidden gap-4 overflow-x-auto pb-4 -mx-4 px-4 scrollbar-hide snap-x snap-mandatory"
        >
          {categories.map((cat, i) => (
            <motion.div 
              key={i} 
              className="flex-shrink-0 w-[280px] snap-start"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
            >
              <div 
                className="flex items-start gap-4 bg-card border border-border/60 rounded-xl p-5 h-full hover:border-border hover:shadow-md transition-all duration-200" 
                data-testid={`card-category-mobile-${i}`}
              >
                <div className={`w-12 h-12 rounded-xl ${cat.color} flex items-center justify-center shrink-0`}>
                  <cat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-semibold mb-1">{cat.title}</h3>
                  <p className="text-sm text-muted-foreground leading-snug">{cat.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Desktop: Grid */}
        <motion.div 
          className="hidden lg:grid grid-cols-3 gap-6" 
          initial="hidden" 
          whileInView="visible" 
          viewport={{ once: true, margin: "-80px" }} 
          variants={staggerContainer}
        >
          {categories.map((cat, i) => (
            <motion.div key={i} variants={fadeUp} transition={{ duration: 0.4 }}>
              <div 
                className="flex items-start gap-5 bg-card border border-border/60 rounded-xl p-6 hover:border-border hover:shadow-lg transition-all duration-200" 
                data-testid={`card-category-${i}`}
              >
                <div className={`w-14 h-14 rounded-xl ${cat.color} flex items-center justify-center shrink-0`}>
                  <cat.icon className="w-7 h-7 text-white" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-semibold mb-1.5 text-lg">{cat.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{cat.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
