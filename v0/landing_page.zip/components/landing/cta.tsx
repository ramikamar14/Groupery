"use client";

import { Button } from "@/components/ui/button";
import { ArrowRight, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import { fadeIn } from "@/lib/animations";
import { t } from "@/lib/translations";

export function CTA() {
  return (
    <section className="py-0">
      <motion.div 
        className="w-full"
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-80px" }} 
        variants={fadeIn} 
        transition={{ duration: 0.6 }}
      >
        <div className="relative bg-gradient-to-br from-primary via-primary to-accent overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-0 left-0 w-[600px] h-[600px] bg-white/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
            <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-accent/30 rounded-full blur-3xl translate-x-1/4 translate-y-1/4" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-white/[0.03] rounded-full blur-3xl" />
          </div>
          
          <div className="relative max-w-4xl mx-auto px-4 sm:px-6 py-24 sm:py-32 text-center">
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 text-balance" data-testid="text-cta-title">
              {t("landing.ctaTitle")}
            </h2>
            <p className="text-white/80 mb-10 max-w-2xl mx-auto text-lg sm:text-xl leading-relaxed" data-testid="text-cta-subtitle">
              Join thousands of smart shoppers already saving money with group buying. Start your first deal today — it&apos;s free!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                asChild 
                className="bg-white text-primary hover:bg-white/95 shadow-2xl gap-2 font-semibold h-14 px-8 text-base" 
                data-testid="button-cta"
              >
                <a href="/api/login">{t("landing.ctaButton")}<ArrowRight className="w-5 h-5" /></a>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                asChild 
                className="border-white/30 text-white hover:bg-white/10 hover:text-white gap-2 h-14 px-8 text-base bg-transparent"
              >
                <a href="#how-it-works">
                  Learn more <ChevronRight className="w-5 h-5" />
                </a>
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
