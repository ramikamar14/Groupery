"use client";

import { Button } from "@/components/ui/button";
import { ArrowRight, Globe } from "lucide-react";
import { LogoIcon } from "./logo";
import { t } from "@/lib/translations";

function LanguageSwitcher() {
  return (
    <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground">
      <Globe className="w-4 h-4" />
      <span className="hidden sm:inline">EN</span>
    </Button>
  );
}

export function Header() {
  return (
    <header className="sticky top-0 z-50 glass border-b border-border/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3" data-testid="text-brand">
          <LogoIcon size={36} />
          <span className="text-lg font-bold tracking-tight">Grouperry</span>
        </div>
        <div className="flex items-center gap-2">
          <LanguageSwitcher />
          <Button asChild size="sm" variant="ghost" data-testid="button-sign-in-secondary">
            <a href="/api/login">{t("landing.signIn")}</a>
          </Button>
          <Button asChild size="sm" className="gap-1.5 bg-accent hover:bg-accent/90 text-accent-foreground" data-testid="button-get-started-header">
            <a href="/api/login">
              Get started <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </Button>
        </div>
      </div>
    </header>
  );
}
