export function LogoIcon({ size = 32 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" rx="10" className="fill-primary" />
      <path
        d="M12 20C12 15.5817 15.5817 12 20 12C24.4183 12 28 15.5817 28 20"
        stroke="white"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <circle cx="14" cy="24" r="3" fill="white" />
      <circle cx="20" cy="26" r="3" fill="white" />
      <circle cx="26" cy="24" r="3" fill="white" />
    </svg>
  );
}
