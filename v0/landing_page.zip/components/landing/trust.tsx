"use client";

import { ShieldCheck, Star, Flag, MessageCircle, Banknote, type LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { fadeUp, staggerContainer } from "@/lib/animations";
import { t } from "@/lib/translations";

interface TrustFeature {
  icon: LucideIcon;
  title: string;
  desc: string;
}

export function Trust() {
  const trustFeatures: TrustFeature[] = [
    { icon: ShieldCheck, title: t("landing.trustVerifiedTitle"), desc: t("landing.trustVerifiedDesc") },
    { icon: Star, title: t("landing.trustRatingsTitle"), desc: t("landing.trustRatingsDesc") },
    { icon: Flag, title: t("landing.trustModerationTitle"), desc: t("landing.trustModerationDesc") },
    { icon: MessageCircle, title: t("landing.trustChatTitle"), desc: t("landing.trustChatDesc") },
    { icon: Banknote, title: t("landing.noPayments"), desc: t("landing.noPaymentsDesc") },
  ];

  return (
    <section className="py-28 sm:py-36">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div 
          className="text-center mb-20" 
          initial="hidden" 
          whileInView="visible" 
          viewport={{ once: true, margin: "-80px" }} 
          variants={fadeUp} 
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl sm:text-5xl font-bold text-balance" data-testid="text-trust-title">{t("landing.trustTitle")}</h2>
        </motion.div>
        
        <motion.div 
          className="space-y-8" 
          initial="hidden" 
          whileInView="visible" 
          viewport={{ once: true, margin: "-80px" }} 
          variants={staggerContainer}
        >
          {trustFeatures.map((feat, i) => (
            <motion.div key={i} variants={fadeUp} transition={{ duration: 0.4 }}>
              <div 
                className={`flex flex-col sm:flex-row items-center gap-6 sm:gap-10 bg-card border border-border/60 rounded-2xl p-8 sm:p-10 hover:shadow-lg transition-all duration-200 ${
                  i % 2 === 1 ? "sm:flex-row-reverse" : ""
                }`} 
                data-testid={`card-trust-${i}`}
              >
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-accent/15 flex items-center justify-center shrink-0">
                  <feat.icon className="w-10 h-10 sm:w-12 sm:h-12 text-accent" />
                </div>
                <div className={`text-center sm:text-left flex-1 ${i % 2 === 1 ? "sm:text-right" : ""}`}>
                  <h3 className="font-semibold mb-2 text-xl">{feat.title}</h3>
                  <p className="text-muted-foreground leading-relaxed max-w-lg">{feat.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
