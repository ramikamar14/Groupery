"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Users, Sparkles, Zap, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";
import { fadeUp, staggerContainer } from "@/lib/animations";
import { t } from "@/lib/translations";

interface HeroProps {
  totalMembers?: number;
}

export function Hero({ totalMembers = 12500 }: HeroProps) {
  const avatars = [
    "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face",
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
    "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=100&h=100&fit=crop&crop=face",
    "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
  ];

  return (
    <section className="relative overflow-hidden pt-20 pb-28 sm:pt-32 sm:pb-40">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-48 -left-48 w-[500px] h-[500px] bg-accent/15 rounded-full blur-3xl" />
        <div className="absolute -top-24 right-0 w-[400px] h-[400px] bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-[350px] h-[350px] bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
        <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-20">
          {/* Hero Text */}
          <motion.div 
            className="flex-1 space-y-8 text-center lg:text-start" 
            initial="hidden" 
            animate="visible" 
            variants={staggerContainer}
          >
            <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
              <Badge variant="secondary" className="gap-2 px-4 py-1.5 text-sm font-medium mb-8 inline-flex border border-accent/30 bg-accent/10 text-accent">
                <Sparkles className="w-4 h-4" />
                AI-powered group buying
              </Badge>
            </motion.div>
            
            <motion.h1 
              className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.05] text-balance" 
              variants={fadeUp} 
              transition={{ duration: 0.5 }} 
              data-testid="text-hero-title"
            >
              {t("landing.heroTitle")}
              <br />
              <span className="bg-gradient-to-r from-accent via-accent/80 to-accent bg-clip-text text-transparent">
                {t("landing.heroTitleHighlight")}
              </span>
            </motion.h1>
            
            <motion.p 
              className="text-lg sm:text-xl text-muted-foreground max-w-xl mx-auto lg:mx-0 leading-relaxed" 
              variants={fadeUp} 
              transition={{ duration: 0.5 }} 
              data-testid="text-hero-subtitle"
            >
              {t("landing.heroSubtitle")}
            </motion.p>
            
            <motion.div variants={fadeUp} transition={{ duration: 0.5 }} className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-2">
              <Button 
                size="lg" 
                asChild 
                className="gap-2 h-14 px-8 text-base shadow-xl shadow-accent/25 hover:shadow-accent/40 transition-shadow bg-accent hover:bg-accent/90 text-accent-foreground" 
                data-testid="button-get-started"
              >
                <a href="/api/login">{t("landing.getStarted")}<ArrowRight className="w-5 h-5" /></a>
              </Button>
              <Button size="lg" variant="outline" asChild className="gap-2 h-14 px-8 text-base border-border/80" data-testid="button-learn-more">
                <a href="#how-it-works">See how it works</a>
              </Button>
            </motion.div>
            
            <motion.div variants={fadeUp} transition={{ duration: 0.5 }} className="flex items-center gap-5 justify-center lg:justify-start flex-wrap pt-4">
              <div className="flex -space-x-3">
                {avatars.map((src, i) => (
                  <div key={i} className="w-10 h-10 rounded-full border-[3px] border-background overflow-hidden">
                    <img src={src} alt="" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
              <p className="text-base text-muted-foreground">
                <span className="font-semibold text-foreground">
                  {totalMembers > 0 ? `${totalMembers.toLocaleString()}+` : "Growing community of"}
                </span>{" "}members saving together
              </p>
            </motion.div>
          </motion.div>

          {/* Hero Image with Floating Cards */}
          <motion.div 
            className="flex-1 w-full max-w-xl" 
            initial={{ opacity: 0, scale: 0.92, y: 24 }} 
            animate={{ opacity: 1, scale: 1, y: 0 }} 
            transition={{ delay: 0.3, duration: 0.7 }}
          >
            <div className="relative">
              {/* Main image */}
              <div className="aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl shadow-black/20 border border-white/10 ring-1 ring-black/5">
                <img 
                  src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?q=80&w=2532&auto=format&fit=crop" 
                  alt="Group collaboration" 
                  className="w-full h-full object-cover" 
                  data-testid="img-hero" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/70 via-primary/20 to-transparent" />
              </div>
              
              {/* Floating card - Bottom Left */}
              <motion.div 
                className="absolute -bottom-6 -left-6 bg-card border border-border rounded-2xl px-5 py-4 shadow-2xl shadow-black/15" 
                animate={{ y: [0, -8, 0] }} 
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500 flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-base font-semibold">Save up to 30%</p>
                    <p className="text-sm text-muted-foreground">on every group deal</p>
                  </div>
                </div>
              </motion.div>
              
              {/* Floating card - Top Right */}
              <motion.div 
                className="absolute -top-6 -right-6 bg-card border border-border rounded-2xl px-5 py-4 shadow-2xl shadow-black/15" 
                animate={{ y: [0, 8, 0] }} 
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 2 }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-accent flex items-center justify-center">
                    <Users className="w-6 h-6 text-accent-foreground" />
                  </div>
                  <div>
                    <p className="text-base font-semibold">847+ Deals</p>
                    <p className="text-sm text-muted-foreground">active right now</p>
                  </div>
                </div>
              </motion.div>

              {/* Floating card - Middle Right */}
              <motion.div 
                className="absolute top-1/2 -right-4 -translate-y-1/2 bg-card border border-border rounded-xl px-4 py-3 shadow-xl shadow-black/10" 
                animate={{ x: [0, 6, 0] }} 
                transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                    <Zap className="w-4 h-4 text-primary-foreground" />
                  </div>
                  <p className="text-sm font-medium">AI-Matched</p>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
