"use client";

import { Users, TrendingUp, Banknote, Globe, type LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { fadeUp, staggerContainer } from "@/lib/animations";
import { t } from "@/lib/translations";

interface StatsProps {
  activeListings?: number;
  totalMembers?: number;
}

interface StatItem {
  value: string;
  label: string;
  icon: LucideIcon;
}

export function Stats({ activeListings = 847, totalMembers = 12500 }: StatsProps) {
  const stats: StatItem[] = [
    {
      value: activeListings > 0 ? `${activeListings}` : "Growing",
      label: t("landing.statsGroups"),
      icon: Users,
    },
    {
      value: totalMembers > 0 ? `${totalMembers.toLocaleString()}+` : "Early Access",
      label: t("landing.statsMembers"),
      icon: TrendingUp,
    },
    { value: "30%", label: t("landing.statsSaved"), icon: Banknote },
    { value: "Global", label: t("landing.statsCountries"), icon: Globe },
  ];

  return (
    <section className="border-y border-border/60 bg-primary py-12 sm:py-14">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div 
          className="grid grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-12" 
          initial="hidden" 
          whileInView="visible" 
          viewport={{ once: true, margin: "-60px" }} 
          variants={staggerContainer}
        >
          {stats.map((stat, i) => (
            <motion.div 
              key={i} 
              className="flex flex-col items-center gap-3 text-center" 
              variants={fadeUp} 
              transition={{ duration: 0.4 }} 
              data-testid={`stat-${i}`}
            >
              <div className="w-14 h-14 rounded-xl bg-accent flex items-center justify-center">
                <stat.icon className="w-7 h-7 text-accent-foreground" />
              </div>
              <div className="text-4xl sm:text-5xl font-bold text-primary-foreground tracking-tight">{stat.value}</div>
              <div className="text-sm sm:text-base text-primary-foreground/70 font-medium">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
