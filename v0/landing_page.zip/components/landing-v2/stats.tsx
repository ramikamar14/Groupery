"use client";

import { motion } from "framer-motion";
import { t } from "@/lib/translations";
import { Users, ShoppingBag, TrendingUp, Globe, Sparkles } from "lucide-react";

const stats = [
  {
    icon: ShoppingBag,
    value: "12,400+",
    label: t("landing.statsGroups"),
    color: "from-violet-500 to-purple-600",
    bgColor: "bg-violet-100",
    iconColor: "text-violet-600",
  },
  {
    icon: Users,
    value: "847K",
    label: t("landing.statsMembers"),
    color: "from-blue-500 to-cyan-500",
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600",
  },
  {
    icon: TrendingUp,
    value: "31%",
    label: t("landing.statsSaved"),
    color: "from-emerald-500 to-green-500",
    bgColor: "bg-emerald-100",
    iconColor: "text-emerald-600",
  },
  {
    icon: Globe,
    value: "89",
    label: t("landing.statsCountries"),
    color: "from-orange-500 to-amber-500",
    bgColor: "bg-orange-100",
    iconColor: "text-orange-600",
  },
];

export function Stats() {
  return (
    <section className="py-20 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/[0.02] to-transparent" />
      
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <p className="text-sm font-medium text-primary mb-2 tracking-wide uppercase flex items-center justify-center gap-2">
            <Sparkles className="size-4" />
            {t("v2.statsTagline")}
          </p>
        </motion.div>

        {/* Bento-style grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 max-w-5xl mx-auto">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="group relative"
            >
              <div className="relative bg-card rounded-3xl p-6 lg:p-8 border border-border/50 shadow-sm hover:shadow-xl transition-all duration-300 h-full">
                {/* Gradient overlay on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 rounded-3xl transition-opacity duration-300`} />
                
                {/* Icon */}
                <div className={`${stat.bgColor} size-14 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <stat.icon className={`size-7 ${stat.iconColor}`} />
                </div>

                {/* Value */}
                <div className="text-3xl lg:text-4xl font-bold mb-1 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
                  {stat.value}
                </div>

                {/* Label */}
                <div className="text-sm text-muted-foreground font-medium">
                  {stat.label}
                </div>

                {/* Decorative dot */}
                <div className={`absolute top-4 right-4 size-2 rounded-full bg-gradient-to-r ${stat.color} opacity-50`} />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
