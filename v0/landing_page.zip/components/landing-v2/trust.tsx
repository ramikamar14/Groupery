"use client";

import { motion } from "framer-motion";
import { BadgeCheck, ShieldCheck, Zap, Heart, Quote } from "lucide-react";
import { t } from "@/lib/translations";

const features = [
  {
    icon: BadgeCheck,
    title: "Verified Members",
    description: "Every member goes through our verification process",
    color: "text-blue-600",
    bg: "bg-blue-100",
  },
  {
    icon: ShieldCheck,
    title: "Buyer Protection",
    description: "Full refund if deal doesn't go through",
    color: "text-green-600",
    bg: "bg-green-100",
  },
  {
    icon: Zap,
    title: "Instant Groups",
    description: "AI matches you with perfect buying groups",
    color: "text-amber-600",
    bg: "bg-amber-100",
  },
  {
    icon: Heart,
    title: "Community First",
    description: "Built by shoppers, for shoppers",
    color: "text-rose-600",
    bg: "bg-rose-100",
  },
];

const testimonials = [
  {
    quote: "Saved $400 on my new laptop by joining a group buy. This is the future of shopping!",
    author: "Sarah M.",
    role: "Tech enthusiast",
    avatar: 1,
  },
  {
    quote: "Our office saves thousands every month on software subscriptions through Grouperry.",
    author: "David K.",
    role: "Startup founder",
    avatar: 2,
  },
  {
    quote: "I love connecting with other parents to get bulk deals on kids essentials.",
    author: "Maria L.",
    role: "Mom of 3",
    avatar: 3,
  },
];

export function Trust() {
  return (
    <section id="trust" className="py-24 bg-gradient-to-b from-muted/50 to-background relative overflow-hidden">
      <div className="container mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-sm font-medium text-primary mb-2 tracking-wide uppercase">
            {t("v2.trustTagline")}
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground">
            {t("v2.trustTitle")}
          </h2>
        </motion.div>

        {/* Two-column layout: Features + Testimonials */}
        <div className="grid lg:grid-cols-2 gap-12 items-start max-w-6xl mx-auto">
          {/* Left: Feature pills */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-4"
          >
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center gap-4 p-4 rounded-2xl bg-card border border-border/50 hover:shadow-lg transition-shadow"
              >
                <div className={`size-12 rounded-xl ${feature.bg} flex items-center justify-center shrink-0`}>
                  <feature.icon className={`size-6 ${feature.color}`} />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Right: Testimonial stack */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="space-y-4">
              {testimonials.map((testimonial, i) => (
                <motion.div
                  key={testimonial.author}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + i * 0.1 }}
                  className="relative bg-card rounded-2xl p-6 border border-border/50 shadow-sm hover:shadow-lg transition-shadow"
                >
                  <Quote className="absolute top-4 right-4 size-8 text-primary/10" />
                  <p className="text-foreground mb-4 italic leading-relaxed">
                    &ldquo;{testimonial.quote}&rdquo;
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="size-10 rounded-full overflow-hidden">
                      <img
                        src={`https://i.pravatar.cc/40?img=${testimonial.avatar + 20}`}
                        alt={testimonial.author}
                        className="size-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-foreground">
                        {testimonial.author}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {testimonial.role}
                      </div>
                    </div>
                    <div className="ml-auto flex gap-0.5">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <span key={star} className="text-yellow-400 text-sm">★</span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Decorative floating badge */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute -top-4 -right-4 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-semibold shadow-lg hidden lg:flex items-center gap-2"
            >
              <ShieldCheck className="size-4" />
              100% Secure
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
